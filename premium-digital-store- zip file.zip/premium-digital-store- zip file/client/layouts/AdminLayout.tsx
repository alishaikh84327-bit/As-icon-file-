import { Outlet, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";

export default function AdminLayout() {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const adminToken = localStorage.getItem("adminToken");
    setIsAdminLoggedIn(!!adminToken);
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] to-[#1a1a2e] flex items-center justify-center">
        <div className="text-neon-blue text-lg">Loading...</div>
      </div>
    );
  }

  if (!isAdminLoggedIn) {
    return <Outlet />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] to-[#1a1a2e] text-white">
      <Outlet />
    </div>
  );
}
