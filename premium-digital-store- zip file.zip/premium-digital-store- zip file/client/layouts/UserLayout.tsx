import { Outlet, Link } from "react-router-dom";
import { Menu, X, LogOut } from "lucide-react";
import { useState, useEffect } from "react";

export default function UserLayout() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(
    !!localStorage.getItem("userToken")
  );

  useEffect(() => {
    // Update login state when storage changes
    const handleStorageChange = () => {
      setIsLoggedIn(!!localStorage.getItem("userToken"));
    };

    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("userToken");
    localStorage.removeItem("userData");
    setIsLoggedIn(false);
    window.location.href = "/";
  };

  const menuItems = isLoggedIn
    ? [
        { label: "Home", href: "/" },
        { label: "Products", href: "/products" },
        { label: "My Orders", href: "/my-orders" },
        { label: "Logout", href: "#", onClick: handleLogout },
        { label: "Admin Login", href: "/admin", divider: true },
      ]
    : [
        { label: "Home", href: "/" },
        { label: "Products", href: "/products" },
        { label: "Login", href: "/login" },
        { label: "Register", href: "/register" },
        { label: "Admin Login", href: "/admin", divider: true },
      ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] to-[#1a1a2e] text-white flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-black/40 backdrop-blur-md border-b border-neon-blue/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-neon-blue to-blue-500 flex items-center justify-center font-bold text-black">
                AS
              </div>
              <span className="hidden sm:inline font-bold text-lg">
                AS Store
              </span>
            </Link>

            {/* Desktop Menu */}
            <nav className="hidden md:flex items-center gap-8">
              {menuItems.map((item, idx) => {
                if (item.divider) {
                  return (
                    <div key={item.label} className="hidden lg:flex items-center gap-8 border-l border-neon-blue/20 pl-8">
                      <Link
                        to={item.href}
                        className="text-sm hover:text-neon-blue transition duration-300 text-neon-blue font-semibold"
                      >
                        {item.label}
                      </Link>
                    </div>
                  );
                }

                if (item.label === "Logout") {
                  return (
                    <button
                      key={item.label}
                      onClick={item.onClick}
                      className="flex items-center gap-2 text-sm hover:text-neon-blue transition duration-300 text-gray-400"
                    >
                      <LogOut size={16} />
                      {item.label}
                    </button>
                  );
                }

                return (
                  <Link
                    key={item.label}
                    to={item.href}
                    className="text-sm hover:text-neon-blue transition duration-300 text-gray-400"
                  >
                    {item.label}
                  </Link>
                );
              })}
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 hover:bg-blue-500/10 rounded-lg transition"
            >
              {mobileMenuOpen ? (
                <X size={24} className="text-neon-blue" />
              ) : (
                <Menu size={24} />
              )}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4 border-t border-neon-blue/10 mt-4 pt-4">
              <nav className="flex flex-col gap-2">
                {menuItems.map((item) => {
                  if (item.divider) {
                    return (
                      <div key={item.label} className="border-t border-neon-blue/20 pt-2 mt-2">
                        <Link
                          to={item.href}
                          onClick={() => setMobileMenuOpen(false)}
                          className="px-3 py-2 text-sm hover:bg-blue-500/10 rounded-lg transition text-neon-blue font-semibold block"
                        >
                          {item.label}
                        </Link>
                      </div>
                    );
                  }

                  if (item.label === "Logout") {
                    return (
                      <button
                        key={item.label}
                        onClick={item.onClick}
                        className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-blue-500/10 rounded-lg transition w-full text-left text-neon-blue"
                      >
                        <LogOut size={16} />
                        {item.label}
                      </button>
                    );
                  }

                  return (
                    <Link
                      key={item.label}
                      to={item.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className="px-3 py-2 text-sm hover:bg-blue-500/10 rounded-lg transition text-gray-400 hover:text-neon-blue"
                    >
                      {item.label}
                    </Link>
                  );
                })}
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="border-t border-neon-blue/10 bg-black/40 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-neon-blue to-blue-500 flex items-center justify-center font-bold text-black text-sm">
                AS
              </div>
              <span className="font-semibold">AS Premium Store</span>
            </div>
            <p className="text-gray-400 text-sm">
              © 2024 All Rights Reserved
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
