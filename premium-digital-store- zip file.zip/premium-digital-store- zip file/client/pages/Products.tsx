import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ShoppingCart, Package, Zap } from "lucide-react";

interface Product {
  id: string;
  name: string;
  type: "ZIP" | "APK" | "HTML" | "WEBSITE_LINK";
  price: number;
  image: string;
  description: string;
}

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = () => {
    // Load from localStorage (admin will add products)
    const stored = localStorage.getItem("products");
    if (stored) {
      setProducts(JSON.parse(stored));
    } else {
      // Demo products
      setProducts([]);
    }
    setLoading(false);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "ZIP":
        return "📦";
      case "APK":
        return "📱";
      case "HTML":
        return "💻";
      case "WEBSITE_LINK":
        return "🌐";
      default:
        return "📄";
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "WEBSITE_LINK":
        return "Website Link";
      default:
        return type;
    }
  };

  const handleBuyClick = (productId: string) => {
    const isLoggedIn = !!localStorage.getItem("userToken");
    if (!isLoggedIn) {
      window.location.href = "/login";
      return;
    }
    window.location.href = `/payment/${productId}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-neon-blue text-lg">Loading products...</div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          Our <span className="text-neon-blue">Products</span>
        </h1>
        <p className="text-gray-400 text-lg">
          Browse and purchase premium digital products
        </p>
      </div>

      {products.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Package size={48} className="text-gray-600 mb-4" />
          <h2 className="text-2xl font-semibold text-gray-300 mb-2">
            No Products Available
          </h2>
          <p className="text-gray-400 mb-6 max-w-md">
            The product store is currently empty. Check back later for available digital products!
          </p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-6 py-2 rounded-lg font-semibold transition-all duration-300 border border-neon-blue bg-blue-600 text-white hover:bg-blue-700 hover:shadow-blue-glow-lg shadow-blue-glow"
          >
            Return to Home
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="card-glow overflow-hidden group cursor-pointer"
            >
              {/* Product Image */}
              <div className="mb-4 h-40 bg-gradient-to-br from-blue-600/20 to-blue-700/20 rounded-lg flex items-center justify-center text-6xl overflow-hidden">
                {product.image ? (
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                ) : (
                  <span>{getTypeIcon(product.type)}</span>
                )}
              </div>

              {/* Product Info */}
              <div className="mb-4">
                <h3 className="text-xl font-bold mb-2 line-clamp-2">
                  {product.name}
                </h3>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm px-2 py-1 rounded bg-blue-600/30 text-neon-blue border border-neon-blue/30">
                    {getTypeLabel(product.type)}
                  </span>
                </div>
                <p className="text-gray-400 text-sm line-clamp-2 mb-3">
                  {product.description || "Premium digital product"}
                </p>
              </div>

              {/* Price and Action */}
              <div className="flex items-center justify-between">
                <div className="text-2xl font-bold text-neon-blue">
                  ₹{product.price}
                </div>
                <button
                  onClick={() => handleBuyClick(product.id)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-all duration-300 hover:shadow-blue-glow font-semibold text-sm"
                >
                  <ShoppingCart size={16} />
                  Buy
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
