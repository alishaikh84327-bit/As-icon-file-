import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Download, ExternalLink, Clock, CheckCircle, XCircle } from "lucide-react";

interface Order {
  id: string;
  productId: string;
  productName: string;
  productType: string;
  price: number;
  utrNumber: string;
  orderDate: string;
  status: "Processing" | "Approved" | "Rejected";
  file?: string;
  websiteLink?: string;
}

export default function MyOrders() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    const userToken = localStorage.getItem("userToken");
    if (!userToken) {
      navigate("/login");
      return;
    }

    loadOrders();
  }, [navigate]);

  const loadOrders = () => {
    const ordersJson = localStorage.getItem("orders");
    if (ordersJson) {
      const allOrders = JSON.parse(ordersJson);
      const userData = localStorage.getItem("userData");
      const userEmail = userData
        ? JSON.parse(userData).email
        : localStorage.getItem("userEmail");

      // Filter orders for current user
      const userOrders = allOrders.filter(
        (o: any) => o.userEmail === userEmail
      );
      setOrders(userOrders);
    }
    setLoading(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Processing":
        return <Clock className="text-yellow-500" size={20} />;
      case "Approved":
        return <CheckCircle className="text-green-500" size={20} />;
      case "Rejected":
        return <XCircle className="text-red-500" size={20} />;
      default:
        return <Clock size={20} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Processing":
        return "bg-yellow-500/10 text-yellow-400 border-yellow-500/30";
      case "Approved":
        return "bg-green-500/10 text-green-400 border-green-500/30";
      case "Rejected":
        return "bg-red-500/10 text-red-400 border-red-500/30";
      default:
        return "bg-gray-500/10 text-gray-400 border-gray-500/30";
    }
  };

  const handleDownload = (order: Order) => {
    if (order.productType === "WEBSITE_LINK" && order.websiteLink) {
      window.open(order.websiteLink, "_blank");
    } else if (order.file) {
      const link = document.createElement("a");
      link.href = order.file;
      link.download = `${order.productName}`;
      link.click();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-neon-blue">Loading orders...</div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          My <span className="text-neon-blue">Orders</span>
        </h1>
        <p className="text-gray-400 text-lg">
          Track your purchases and download files
        </p>
      </div>

      {orders.length === 0 ? (
        <div className="card-glow text-center py-12">
          <Clock size={48} className="mx-auto text-gray-600 mb-4" />
          <h2 className="text-2xl font-semibold text-gray-300 mb-2">
            No Orders Yet
          </h2>
          <p className="text-gray-400 mb-6">
            You haven't made any purchases yet. Start by browsing our products!
          </p>
          <button
            onClick={() => navigate("/products")}
            className="inline-block px-6 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition font-semibold"
          >
            Browse Products
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div key={order.id} className="card-glow">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                <div>
                  <p className="text-gray-400 text-sm mb-1">Product Name</p>
                  <p className="font-semibold">{order.productName}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Price</p>
                  <p className="font-semibold text-neon-blue">₹{order.price}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Order Date</p>
                  <p className="text-sm">
                    {new Date(order.orderDate).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Status</p>
                  <div
                    className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm border ${getStatusColor(
                      order.status
                    )}`}
                  >
                    {getStatusIcon(order.status)}
                    {order.status}
                  </div>
                </div>
              </div>

              <div className="border-t border-neon-blue/20 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-gray-400 text-sm mb-1">UTR Number</p>
                    <p className="font-mono text-sm">{order.utrNumber}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm mb-1">Product Type</p>
                    <p className="text-sm">{order.productType}</p>
                  </div>
                </div>

                {/* Action Button */}
                <div className="flex items-center gap-4 mt-4">
                  {order.status === "Processing" && (
                    <p className="text-yellow-400 text-sm flex items-center gap-1">
                      <Clock size={16} />
                      Waiting for approval
                    </p>
                  )}
                  {order.status === "Approved" && (
                    <button
                      onClick={() => handleDownload(order)}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 transition font-semibold text-sm"
                    >
                      {order.productType === "WEBSITE_LINK" ? (
                        <>
                          <ExternalLink size={16} />
                          Open Website
                        </>
                      ) : (
                        <>
                          <Download size={16} />
                          Download {order.productType}
                        </>
                      )}
                    </button>
                  )}
                  {order.status === "Rejected" && (
                    <p className="text-red-400 text-sm">
                      Order rejected. Please contact support.
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
