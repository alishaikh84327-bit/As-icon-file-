import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Copy, CheckCircle, AlertCircle } from "lucide-react";

interface Product {
  id: string;
  name: string;
  price: number;
}

export default function Payment() {
  const { productId } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  const UPI_ID = "9818578419@fam";
  const QR_CODE_URL =
    "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi%3A%2F%2Fpay%3Fpa%3D9818578419%40fam%26pn%3DAS%2520Store";

  useEffect(() => {
    // Get product from localStorage
    const products = localStorage.getItem("products");
    if (products) {
      const productsList = JSON.parse(products);
      const found = productsList.find((p: any) => p.id === productId);
      if (found) {
        setProduct(found);
      }
    }
    setLoading(false);
  }, [productId]);

  const handleCopyUPI = () => {
    navigator.clipboard.writeText(UPI_ID);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-neon-blue">Loading...</div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="card-glow text-center">
          <AlertCircle size={48} className="mx-auto text-red-400 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Product Not Found</h2>
          <p className="text-gray-400 mb-4">The product you're trying to buy doesn't exist.</p>
          <button
            onClick={() => navigate("/products")}
            className="px-6 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition"
          >
            Back to Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-100px)] flex items-center justify-center py-8">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold mb-2">Complete Payment</h1>
          <p className="text-gray-400">Secure UPI payment for your digital product</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Details */}
          <div className="card-glow">
            <h2 className="text-xl font-bold mb-4">Order Summary</h2>
            <div className="space-y-4">
              <div>
                <p className="text-gray-400 text-sm">Product Name</p>
                <p className="text-lg font-semibold">{product.name}</p>
              </div>
              <div className="border-t border-neon-blue/20 pt-4">
                <p className="text-gray-400 text-sm">Amount to Pay</p>
                <p className="text-3xl font-bold text-neon-blue">₹{product.price}</p>
              </div>
              <div className="border-t border-neon-blue/20 pt-4 bg-blue-600/10 -m-4 p-4">
                <p className="text-sm text-gray-400 mb-2">Payment Methods Accepted:</p>
                <div className="flex flex-wrap gap-2">
                  {["Google Pay", "PhonePe", "Paytm", "FamPay", "BHIM UPI"].map(
                    (method) => (
                      <span
                        key={method}
                        className="text-xs px-2 py-1 rounded bg-neon-blue/10 border border-neon-blue/30 text-neon-blue"
                      >
                        {method}
                      </span>
                    )
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Payment Instructions */}
          <div className="card-glow">
            <h2 className="text-xl font-bold mb-4">Payment Instructions</h2>

            {/* QR Code */}
            <div className="mb-6 p-4 bg-white rounded-lg flex items-center justify-center">
              <img
                src={QR_CODE_URL}
                alt="UPI QR Code"
                className="w-full max-w-xs"
              />
            </div>

            {/* UPI ID */}
            <div className="mb-4">
              <p className="text-gray-400 text-sm mb-2">UPI ID</p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={UPI_ID}
                  readOnly
                  className="flex-1 px-3 py-2 bg-black/50 border border-neon-blue/30 rounded-lg text-white text-sm"
                />
                <button
                  onClick={handleCopyUPI}
                  className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition flex items-center gap-2 text-sm"
                >
                  {copied ? (
                    <CheckCircle size={16} />
                  ) : (
                    <Copy size={16} />
                  )}
                </button>
              </div>
            </div>

            {/* Steps */}
            <div className="space-y-2 text-sm text-gray-300">
              <p className="font-semibold text-white">Steps:</p>
              <ol className="list-decimal list-inside space-y-1">
                <li>Open any UPI app</li>
                <li>Scan QR code or pay to: 9818578419@fam</li>
                <li>Pay ₹{product.price}</li>
                <li>Copy UTR number</li>
                <li>Take screenshot</li>
                <li>Upload on next page</li>
              </ol>
            </div>
          </div>
        </div>

        {/* Next Button */}
        <div className="mt-8 flex justify-center">
          <button
            onClick={() =>
              navigate(`/payment/${productId}`, {
                state: { productId, product },
              })
            }
            className="px-8 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-300 shadow-blue-glow hover:shadow-blue-glow-lg"
          >
            After Payment, Click Here →
          </button>
        </div>
      </div>
    </div>
  );
}
