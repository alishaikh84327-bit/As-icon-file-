import { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Mail, Lock, LogIn, AlertCircle, CheckCircle } from "lucide-react";

interface ValidationError {
  field: string;
  message: string;
}

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState<ValidationError[]>([]);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    // Show success message from registration
    if (location.state?.message) {
      setSuccessMessage(location.state.message);
      setTimeout(() => setSuccessMessage(""), 3000);
    }
  }, [location]);

  const validateForm = () => {
    const newErrors: ValidationError[] = [];

    if (!formData.email.trim()) {
      newErrors.push({ field: "email", message: "Email is required" });
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.push({ field: "email", message: "Invalid email format" });
    }

    if (!formData.password) {
      newErrors.push({ field: "password", message: "Password is required" });
    }

    return newErrors;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error for this field
    setErrors(errors.filter((err) => err.field !== name));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form
    const validationErrors = validateForm();
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    setLoading(true);

    try {
      // Get all users from localStorage
      const usersJson = localStorage.getItem("users");
      const users = usersJson ? JSON.parse(usersJson) : [];

      // Find user with matching email and password
      const user = users.find(
        (u: any) =>
          u.email === formData.email.toLowerCase().trim() &&
          u.password === formData.password
      );

      if (!user) {
        setErrors([
          { field: "general", message: "Invalid email or password" },
        ]);
        setLoading(false);
        return;
      }

      // Generate unique user session with device info
      const userSessionId = `user_${user.id}_${Date.now()}_${Math.random()
        .toString(36)
        .substr(2, 9)}`;

      // Store auth token and user data
      localStorage.setItem("userToken", userSessionId);
      localStorage.setItem(
        "userData",
        JSON.stringify({
          id: user.id,
          name: user.name,
          email: user.email,
          sessionId: userSessionId,
          loginTime: new Date().toISOString(),
        })
      );

      // Track user login
      const userLogins = JSON.parse(
        localStorage.getItem("userLogins") || "{}"
      );
      if (!userLogins[user.id]) {
        userLogins[user.id] = [];
      }
      userLogins[user.id].push({
        sessionId: userSessionId,
        loginTime: new Date().toISOString(),
        device: navigator.userAgent.substring(0, 100),
      });
      localStorage.setItem("userLogins", JSON.stringify(userLogins));

      // Redirect to home
      setTimeout(() => navigate("/"), 500);
    } catch (err) {
      setErrors([{ field: "general", message: "An error occurred. Please try again." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-100px)] flex items-center justify-center">
      <div className="w-full max-w-md">
        <div className="card-glow">
          <div className="text-center mb-8">
            <div className="inline-block w-12 h-12 rounded-lg bg-gradient-to-br from-neon-blue to-blue-500 flex items-center justify-center font-bold text-lg text-black mb-4 shadow-blue-glow">
              AS
            </div>
            <h1 className="text-3xl font-bold mb-2">Welcome Back</h1>
            <p className="text-gray-400">Login to your account</p>
          </div>

          {successMessage && (
            <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/30 text-green-400 text-sm mb-4 flex items-center gap-2">
              <CheckCircle size={16} />
              {successMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email Field */}
            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <div className="relative">
                <Mail
                  size={16}
                  className="absolute left-3 top-3 text-gray-500"
                />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                  className={`w-full pl-9 pr-4 py-2 bg-black/50 border rounded-lg focus:outline-none focus:ring-1 text-white placeholder-gray-600 transition ${
                    errors.some((e) => e.field === "email")
                      ? "border-red-500/50 focus:border-red-500 focus:ring-red-500"
                      : "border-neon-blue/30 focus:border-neon-blue focus:ring-neon-blue"
                  }`}
                />
              </div>
              {errors.find((e) => e.field === "email") && (
                <p className="text-red-400 text-xs mt-1">
                  {errors.find((e) => e.field === "email")?.message}
                </p>
              )}
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-sm font-medium mb-2">Password</label>
              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3 top-3 text-gray-500"
                />
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  className={`w-full pl-9 pr-4 py-2 bg-black/50 border rounded-lg focus:outline-none focus:ring-1 text-white placeholder-gray-600 transition ${
                    errors.some((e) => e.field === "password")
                      ? "border-red-500/50 focus:border-red-500 focus:ring-red-500"
                      : "border-neon-blue/30 focus:border-neon-blue focus:ring-neon-blue"
                  }`}
                />
              </div>
              {errors.find((e) => e.field === "password") && (
                <p className="text-red-400 text-xs mt-1">
                  {errors.find((e) => e.field === "password")?.message}
                </p>
              )}
            </div>

            {/* General Error Message */}
            {errors.find((e) => e.field === "general") && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm flex items-center gap-2">
                <AlertCircle size={16} />
                {errors.find((e) => e.field === "general")?.message}
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-lg font-semibold transition-all duration-300 border border-neon-blue bg-blue-600 text-white hover:bg-blue-700 hover:shadow-blue-glow-lg shadow-blue-glow disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <LogIn size={18} />
              {loading ? "Logging in..." : "Login"}
            </button>
          </form>

          {/* Register Link */}
          <div className="mt-6 pt-6 border-t border-neon-blue/20 text-center">
            <p className="text-gray-400">
              Don't have an account?{" "}
              <Link
                to="/register"
                className="text-neon-blue hover:underline font-semibold"
              >
                Register here
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
