import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Lock, User } from "lucide-react";

const ADMIN_USERNAME = "asicon";
const ADMIN_PASSWORD = "asiconbhai@0786";

// Get device information
const getDeviceInfo = () => {
  const userAgent = navigator.userAgent;
  let browserName = "Unknown";
  let deviceName = "Unknown Device";

  // Detect browser
  if (userAgent.indexOf("Chrome") > -1) browserName = "Chrome";
  else if (userAgent.indexOf("Safari") > -1) browserName = "Safari";
  else if (userAgent.indexOf("Firefox") > -1) browserName = "Firefox";
  else if (userAgent.indexOf("Edge") > -1) browserName = "Edge";

  // Detect device type
  if (/android/i.test(userAgent)) deviceName = "Android Device";
  else if (/iphone|ipad|ipod/i.test(userAgent)) deviceName = "iOS Device";
  else if (/windows/i.test(userAgent)) deviceName = "Windows PC";
  else if (/mac/i.test(userAgent)) deviceName = "Mac";
  else if (/linux/i.test(userAgent)) deviceName = "Linux PC";

  return {
    deviceName,
    browserName,
    loginTime: new Date().toISOString(),
    ipAddress: "Unknown", // IP address would need to come from backend
  };
};

export default function AdminLogin() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ username: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    // Authentication check
    if (
      formData.username === ADMIN_USERNAME &&
      formData.password === ADMIN_PASSWORD
    ) {
      // Generate unique admin session
      const adminSessionId = `admin_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const deviceInfo = getDeviceInfo();

      // Store admin token
      localStorage.setItem("adminToken", adminSessionId);
      localStorage.setItem("adminUsername", ADMIN_USERNAME);

      // Store device info in admin devices array
      const adminDevices = JSON.parse(
        localStorage.getItem("adminDevices") || "[]"
      );
      adminDevices.push({
        id: adminSessionId,
        ...deviceInfo,
      });
      localStorage.setItem("adminDevices", JSON.stringify(adminDevices));

      navigate("/admin/dashboard");
    } else {
      setError("Invalid username or password");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] to-[#1a1a2e] flex items-center justify-center text-white">
      <div className="w-full max-w-md px-4">
        <div className="card-glow">
          <div className="text-center mb-8">
            <div className="inline-block w-12 h-12 rounded-lg bg-gradient-to-br from-neon-blue to-blue-500 flex items-center justify-center font-bold text-lg text-black mb-4 shadow-blue-glow">
              AS
            </div>
            <h1 className="text-3xl font-bold mb-2">Admin Panel</h1>
            <p className="text-gray-400">Manage your digital product store</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Username Field */}
            <div>
              <label className="block text-sm font-medium mb-2">Username</label>
              <div className="relative">
                <User
                  size={16}
                  className="absolute left-3 top-3 text-gray-500"
                />
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleChange}
                  placeholder="admin"
                  required
                  className="w-full pl-9 pr-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg focus:outline-none focus:border-neon-blue focus:ring-1 focus:ring-neon-blue text-white placeholder-gray-600 transition"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-sm font-medium mb-2">Password</label>
              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3 top-3 text-gray-500"
                />
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  required
                  className="w-full pl-9 pr-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg focus:outline-none focus:border-neon-blue focus:ring-1 focus:ring-neon-blue text-white placeholder-gray-600 transition"
                />
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
                {error}
              </div>
            )}

            {/* Demo Credentials */}
            <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs">
              <p className="font-semibold mb-1">Admin Credentials:</p>
              <p>Username: asicon</p>
              <p>Password: asiconbhai@0786</p>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2 rounded-lg font-semibold transition-all duration-300 border border-neon-blue bg-blue-600 text-white hover:bg-blue-700 hover:shadow-blue-glow-lg shadow-blue-glow disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Authenticating..." : "Login to Dashboard"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
