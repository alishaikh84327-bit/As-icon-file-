import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { User, Mail, Lock, UserPlus, AlertCircle } from "lucide-react";

interface ValidationError {
  field: string;
  message: string;
}

export default function Register() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState<ValidationError[]>([]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const validateForm = () => {
    const newErrors: ValidationError[] = [];

    if (!formData.name.trim()) {
      newErrors.push({ field: "name", message: "Name is required" });
    }

    if (!formData.email.trim()) {
      newErrors.push({ field: "email", message: "Email is required" });
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.push({ field: "email", message: "Invalid email format" });
    }

    if (!formData.password) {
      newErrors.push({ field: "password", message: "Password is required" });
    } else if (formData.password.length < 6) {
      newErrors.push({
        field: "password",
        message: "Password must be at least 6 characters",
      });
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.push({
        field: "confirmPassword",
        message: "Passwords do not match",
      });
    }

    return newErrors;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error for this field when user starts typing
    setErrors(errors.filter((err) => err.field !== name));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccess(false);

    // Validate form
    const validationErrors = validateForm();
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    setLoading(true);

    try {
      // Get existing users
      const usersJson = localStorage.getItem("users");
      const users = usersJson ? JSON.parse(usersJson) : [];

      // Check if email already exists
      if (users.some((u: any) => u.email === formData.email.toLowerCase())) {
        setErrors([
          { field: "email", message: "Email already registered" },
        ]);
        setLoading(false);
        return;
      }

      // Create new user
      const newUser = {
        id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        name: formData.name.trim(),
        email: formData.email.toLowerCase().trim(),
        password: formData.password, // In production, this should be hashed
        createdAt: new Date().toISOString(),
        status: "active",
      };

      users.push(newUser);
      localStorage.setItem("users", JSON.stringify(users));

      setSuccess(true);
      setFormData({ name: "", email: "", password: "", confirmPassword: "" });

      // Redirect to login after a short delay
      setTimeout(() => {
        navigate("/login", {
          state: { message: "Account created successfully! Please login." },
        });
      }, 1500);
    } catch (err) {
      setErrors([{ field: "general", message: "An error occurred. Please try again." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-100px)] flex items-center justify-center">
      <div className="w-full max-w-md">
        <div className="card-glow">
          <div className="text-center mb-8">
            <div className="inline-block w-12 h-12 rounded-lg bg-gradient-to-br from-neon-blue to-blue-500 flex items-center justify-center font-bold text-lg text-black mb-4 shadow-blue-glow">
              AS
            </div>
            <h1 className="text-3xl font-bold mb-2">Create Account</h1>
            <p className="text-gray-400">Join our premium store</p>
          </div>

          {success && (
            <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/30 text-green-400 text-sm mb-4 flex items-center gap-2">
              <AlertCircle size={16} />
              Account created successfully! Redirecting to login...
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Name Field */}
            <div>
              <label className="block text-sm font-medium mb-2">Name</label>
              <div className="relative">
                <User
                  size={16}
                  className="absolute left-3 top-3 text-gray-500"
                />
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="John Doe"
                  className={`w-full pl-9 pr-4 py-2 bg-black/50 border rounded-lg focus:outline-none focus:ring-1 text-white placeholder-gray-600 transition ${
                    errors.some((e) => e.field === "name")
                      ? "border-red-500/50 focus:border-red-500 focus:ring-red-500"
                      : "border-neon-blue/30 focus:border-neon-blue focus:ring-neon-blue"
                  }`}
                />
              </div>
              {errors.find((e) => e.field === "name") && (
                <p className="text-red-400 text-xs mt-1">
                  {errors.find((e) => e.field === "name")?.message}
                </p>
              )}
            </div>

            {/* Email Field */}
            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <div className="relative">
                <Mail
                  size={16}
                  className="absolute left-3 top-3 text-gray-500"
                />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                  className={`w-full pl-9 pr-4 py-2 bg-black/50 border rounded-lg focus:outline-none focus:ring-1 text-white placeholder-gray-600 transition ${
                    errors.some((e) => e.field === "email")
                      ? "border-red-500/50 focus:border-red-500 focus:ring-red-500"
                      : "border-neon-blue/30 focus:border-neon-blue focus:ring-neon-blue"
                  }`}
                />
              </div>
              {errors.find((e) => e.field === "email") && (
                <p className="text-red-400 text-xs mt-1">
                  {errors.find((e) => e.field === "email")?.message}
                </p>
              )}
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-sm font-medium mb-2">Password</label>
              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3 top-3 text-gray-500"
                />
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  className={`w-full pl-9 pr-4 py-2 bg-black/50 border rounded-lg focus:outline-none focus:ring-1 text-white placeholder-gray-600 transition ${
                    errors.some((e) => e.field === "password")
                      ? "border-red-500/50 focus:border-red-500 focus:ring-red-500"
                      : "border-neon-blue/30 focus:border-neon-blue focus:ring-neon-blue"
                  }`}
                />
              </div>
              {errors.find((e) => e.field === "password") && (
                <p className="text-red-400 text-xs mt-1">
                  {errors.find((e) => e.field === "password")?.message}
                </p>
              )}
            </div>

            {/* Confirm Password Field */}
            <div>
              <label className="block text-sm font-medium mb-2">
                Confirm Password
              </label>
              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3 top-3 text-gray-500"
                />
                <input
                  type="password"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="••••••••"
                  className={`w-full pl-9 pr-4 py-2 bg-black/50 border rounded-lg focus:outline-none focus:ring-1 text-white placeholder-gray-600 transition ${
                    errors.some((e) => e.field === "confirmPassword")
                      ? "border-red-500/50 focus:border-red-500 focus:ring-red-500"
                      : "border-neon-blue/30 focus:border-neon-blue focus:ring-neon-blue"
                  }`}
                />
              </div>
              {errors.find((e) => e.field === "confirmPassword") && (
                <p className="text-red-400 text-xs mt-1">
                  {errors.find((e) => e.field === "confirmPassword")?.message}
                </p>
              )}
            </div>

            {/* General Error Message */}
            {errors.find((e) => e.field === "general") && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm flex items-center gap-2">
                <AlertCircle size={16} />
                {errors.find((e) => e.field === "general")?.message}
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-lg font-semibold transition-all duration-300 border border-neon-blue bg-blue-600 text-white hover:bg-blue-700 hover:shadow-blue-glow-lg shadow-blue-glow disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <UserPlus size={18} />
              {loading ? "Creating account..." : "Register"}
            </button>
          </form>

          {/* Login Link */}
          <div className="mt-6 pt-6 border-t border-neon-blue/20 text-center">
            <p className="text-gray-400">
              Already have an account?{" "}
              <Link
                to="/login"
                className="text-neon-blue hover:underline font-semibold"
              >
                Login here
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
