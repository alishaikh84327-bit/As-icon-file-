import { Link } from "react-router-dom";
import { ArrowRight, Zap, Shield, Rocket } from "lucide-react";

export default function Index() {
  return (
    <div className="min-h-[calc(100vh-100px)] flex flex-col items-center justify-center">
      {/* Hero Section */}
      <div className="text-center mb-12 animate-fade-in">
        {/* Logo/Title */}
        <div className="flex items-center justify-center gap-3 mb-6">
          <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-neon-blue to-blue-500 flex items-center justify-center font-bold text-2xl text-black shadow-blue-glow-lg">
            AS
          </div>
          <div className="text-left">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold bg-gradient-to-r from-white via-neon-blue to-blue-400 bg-clip-text text-transparent">
              AS Store
            </h1>
            <p className="text-neon-blue text-lg font-semibold mt-1">
              Premium Digital Files
            </p>
          </div>
        </div>

        {/* Subtitle */}
        <p className="text-xl sm:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto">
          Premium Digital Files Store
        </p>
        <p className="text-gray-400 mb-8 max-w-xl mx-auto">
          Download premium digital products instantly. Secure, fast, and reliable delivery.
        </p>

        {/* CTA Button */}
        <Link
          to="/products"
          className="inline-flex items-center gap-2 px-8 py-4 rounded-lg font-semibold transition-all duration-300 border border-neon-blue bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 shadow-blue-glow hover:shadow-blue-glow-lg"
        >
          Browse Products
          <ArrowRight size={20} />
        </Link>
      </div>

      {/* Features Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full mt-16">
        <div className="card-glow">
          <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-blue-600/20 mb-4">
            <Zap className="text-neon-blue" size={24} />
          </div>
          <h3 className="text-lg font-semibold mb-2">Instant Download</h3>
          <p className="text-gray-400">Get instant access to premium digital files after payment approval</p>
        </div>

        <div className="card-glow">
          <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-blue-600/20 mb-4">
            <Shield className="text-neon-blue" size={24} />
          </div>
          <h3 className="text-lg font-semibold mb-2">Secure Payment</h3>
          <p className="text-gray-400">Safe and secure payment through UPI and multiple payment methods</p>
        </div>

        <div className="card-glow">
          <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-blue-600/20 mb-4">
            <Rocket className="text-neon-blue" size={24} />
          </div>
          <h3 className="text-lg font-semibold mb-2">Fast Delivery</h3>
          <p className="text-gray-400">Lightning-fast processing and delivery of your purchased files</p>
        </div>
      </div>
    </div>
  );
}
