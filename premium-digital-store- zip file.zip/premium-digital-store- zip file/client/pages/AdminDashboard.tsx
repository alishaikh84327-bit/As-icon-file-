import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  LogOut,
  BarChart3,
  Package,
  ShoppingCart,
  Users,
  Plus,
  Trash2,
  Edit,
  Check,
  X,
  Eye,
  EyeOff,
  Smartphone,
} from "lucide-react";

interface Product {
  id: string;
  name: string;
  type: "ZIP" | "APK" | "HTML" | "WEBSITE_LINK";
  price: number;
  image?: string;
  description?: string;
  file?: string;
  websiteLink?: string;
}

interface Order {
  id: string;
  productId: string;
  productName: string;
  userEmail: string;
  customerName: string;
  utrNumber: string;
  screenshot?: string;
  orderDate: string;
  status: "Processing" | "Approved" | "Rejected";
}

interface User {
  id: string;
  name: string;
  email: string;
  createdAt: string;
}

interface AdminDevice {
  id: string;
  deviceName: string;
  browserName: string;
  loginTime: string;
  ipAddress: string;
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<
    "dashboard" | "products" | "orders" | "users" | "qr" | "devices"
  >("dashboard");
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [devices, setDevices] = useState<AdminDevice[]>([]);
  const [qrCode, setQrCode] = useState("");
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState<Partial<Product>>({});
  const [showOrderDetails, setShowOrderDetails] = useState<Order | null>(null);

  useEffect(() => {
    // Check admin authentication
    if (!localStorage.getItem("adminToken")) {
      navigate("/admin");
      return;
    }

    loadData();
  }, [navigate]);

  const loadData = () => {
    const productsJson = localStorage.getItem("products");
    setProducts(productsJson ? JSON.parse(productsJson) : []);

    const ordersJson = localStorage.getItem("orders");
    setOrders(ordersJson ? JSON.parse(ordersJson) : []);

    const usersJson = localStorage.getItem("users");
    setUsers(usersJson ? JSON.parse(usersJson) : []);

    const devicesJson = localStorage.getItem("adminDevices");
    setDevices(devicesJson ? JSON.parse(devicesJson) : []);

    const qrCodeJson = localStorage.getItem("qrCode");
    setQrCode(qrCodeJson || "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi%3A%2F%2Fpay%3Fpa%3D9818578419%40fam%26pn%3DAS%2520Store");
  };

  const handleLogout = () => {
    // Remove current device from admin devices
    const currentAdminToken = localStorage.getItem("adminToken");
    const devicesJson = localStorage.getItem("adminDevices");
    if (devicesJson) {
      const allDevices = JSON.parse(devicesJson) as AdminDevice[];
      const updatedDevices = allDevices.filter(d => d.id !== currentAdminToken);
      localStorage.setItem("adminDevices", JSON.stringify(updatedDevices));
    }

    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminUsername");
    navigate("/admin");
  };

  const handleAddProduct = () => {
    if (editingProduct) {
      const updated = products.map((p) =>
        p.id === editingProduct.id ? { ...editingProduct, ...formData } : p
      );
      setProducts(updated);
      localStorage.setItem("products", JSON.stringify(updated));
      setEditingProduct(null);
    } else {
      const newProduct: Product = {
        id: `product_${Date.now()}`,
        name: formData.name || "",
        type: (formData.type as any) || "ZIP",
        price: formData.price || 0,
        image: formData.image,
        description: formData.description,
        file: formData.file,
        websiteLink: formData.websiteLink,
      };
      const updated = [...products, newProduct];
      setProducts(updated);
      localStorage.setItem("products", JSON.stringify(updated));
    }
    setShowAddProduct(false);
    setFormData({});
  };

  const handleDeleteProduct = (id: string) => {
    const updated = products.filter((p) => p.id !== id);
    setProducts(updated);
    localStorage.setItem("products", JSON.stringify(updated));
  };

  const handleApproveOrder = (id: string) => {
    const updated = orders.map((o) =>
      o.id === id ? { ...o, status: "Approved" as const } : o
    );
    setOrders(updated);
    localStorage.setItem("orders", JSON.stringify(updated));
  };

  const handleRejectOrder = (id: string) => {
    const updated = orders.map((o) =>
      o.id === id ? { ...o, status: "Rejected" as const } : o
    );
    setOrders(updated);
    localStorage.setItem("orders", JSON.stringify(updated));
  };

  const handleDeleteUser = (id: string) => {
    const updated = users.filter((u) => u.id !== id);
    setUsers(updated);
    localStorage.setItem("users", JSON.stringify(updated));
  };

  const handleQRCodeUpload = (url: string) => {
    setQrCode(url);
    localStorage.setItem("qrCode", url);
  };

  const stats = {
    totalUsers: users.length,
    totalProducts: products.length,
    totalOrders: orders.length,
    pendingOrders: orders.filter((o) => o.status === "Processing").length,
    approvedOrders: orders.filter((o) => o.status === "Approved").length,
    rejectedOrders: orders.filter((o) => o.status === "Rejected").length,
    activeAdminDevices: devices.length,
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] to-[#1a1a2e] text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-black/40 backdrop-blur-md border-b border-neon-blue/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-neon-blue to-blue-500 flex items-center justify-center font-bold text-black">
                AS
              </div>
              <span className="font-bold text-lg">Admin Dashboard</span>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 transition font-semibold text-sm"
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-8 border-b border-neon-blue/10 pb-4">
          {[
            { id: "dashboard", label: "Dashboard", icon: BarChart3 },
            { id: "products", label: "Products", icon: Package },
            { id: "orders", label: "Orders", icon: ShoppingCart },
            { id: "users", label: "Users", icon: Users },
            { id: "devices", label: "Devices", icon: Smartphone },
            { id: "qr", label: "QR Code", icon: Eye },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() =>
                  setActiveTab(
                    tab.id as "dashboard" | "products" | "orders" | "users" | "devices" | "qr"
                  )
                }
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition text-sm font-semibold ${
                  activeTab === tab.id
                    ? "bg-blue-600 text-white shadow-blue-glow"
                    : "text-gray-400 hover:text-white"
                }`}
              >
                <Icon size={16} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Dashboard Tab */}
        {activeTab === "dashboard" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { label: "Total Users", value: stats.totalUsers },
              { label: "Total Products", value: stats.totalProducts },
              { label: "Total Orders", value: stats.totalOrders },
              { label: "Pending Orders", value: stats.pendingOrders },
              { label: "Approved Orders", value: stats.approvedOrders },
              { label: "Rejected Orders", value: stats.rejectedOrders },
              {
                label: "Active Admin Devices",
                value: stats.activeAdminDevices,
                highlight: true
              },
            ].map((stat, idx) => (
              <div key={idx} className={stat.highlight ? "card-glow border-neon-blue/50" : "card-glow"}>
                <p className="text-gray-400 text-sm mb-2">{stat.label}</p>
                <p className={`text-4xl font-bold ${stat.highlight ? "text-green-400" : "text-neon-blue"}`}>
                  {stat.value} {stat.highlight && stat.value === 1 ? "Device" : stat.highlight ? "Devices" : ""}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* Products Tab */}
        {activeTab === "products" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Product Management</h2>
              <button
                onClick={() => {
                  setEditingProduct(null);
                  setFormData({});
                  setShowAddProduct(!showAddProduct);
                }}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition font-semibold text-sm"
              >
                <Plus size={16} />
                Add Product
              </button>
            </div>

            {showAddProduct && (
              <div className="card-glow mb-6">
                <h3 className="text-lg font-bold mb-4">
                  {editingProduct ? "Edit Product" : "Add New Product"}
                </h3>
                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Product Name"
                    value={formData.name || ""}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    className="w-full px-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-neon-blue"
                  />
                  <select
                    value={formData.type || "ZIP"}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        type: e.target.value as any,
                      })
                    }
                    className="w-full px-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg text-white focus:outline-none focus:border-neon-blue"
                  >
                    <option value="ZIP">ZIP File</option>
                    <option value="APK">APK File</option>
                    <option value="HTML">HTML File</option>
                    <option value="WEBSITE_LINK">Website Link</option>
                  </select>
                  <input
                    type="number"
                    placeholder="Price (₹)"
                    value={formData.price || ""}
                    onChange={(e) =>
                      setFormData({ ...formData, price: parseInt(e.target.value) })
                    }
                    className="w-full px-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-neon-blue"
                  />
                  <input
                    type="text"
                    placeholder="Description"
                    value={formData.description || ""}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    className="w-full px-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-neon-blue"
                  />
                  {formData.type !== "WEBSITE_LINK" && (
                    <input
                      type="text"
                      placeholder="File URL"
                      value={formData.file || ""}
                      onChange={(e) =>
                        setFormData({ ...formData, file: e.target.value })
                      }
                      className="w-full px-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-neon-blue"
                    />
                  )}
                  {formData.type === "WEBSITE_LINK" && (
                    <input
                      type="url"
                      placeholder="Website URL"
                      value={formData.websiteLink || ""}
                      onChange={(e) =>
                        setFormData({ ...formData, websiteLink: e.target.value })
                      }
                      className="w-full px-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-neon-blue"
                    />
                  )}
                  <input
                    type="text"
                    placeholder="Image URL"
                    value={formData.image || ""}
                    onChange={(e) =>
                      setFormData({ ...formData, image: e.target.value })
                    }
                    className="w-full px-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-neon-blue"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={handleAddProduct}
                      className="flex-1 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 transition font-semibold"
                    >
                      {editingProduct ? "Update Product" : "Add Product"}
                    </button>
                    <button
                      onClick={() => {
                        setShowAddProduct(false);
                        setEditingProduct(null);
                        setFormData({});
                      }}
                      className="flex-1 py-2 rounded-lg bg-gray-600 text-white hover:bg-gray-700 transition font-semibold"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <div key={product.id} className="card-glow">
                  <h3 className="text-lg font-bold mb-2">{product.name}</h3>
                  <p className="text-gray-400 text-sm mb-2">
                    Type: {product.type}
                  </p>
                  <p className="text-neon-blue font-semibold mb-4">
                    ₹{product.price}
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setEditingProduct(product);
                        setFormData(product);
                        setShowAddProduct(true);
                      }}
                      className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition text-sm font-semibold"
                    >
                      <Edit size={14} />
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteProduct(product.id)}
                      className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 transition text-sm font-semibold"
                    >
                      <Trash2 size={14} />
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {products.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-400">No products yet. Add your first product!</p>
              </div>
            )}
          </div>
        )}

        {/* Orders Tab */}
        {activeTab === "orders" && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Order Management</h2>
            <div className="space-y-4">
              {orders.map((order) => (
                <div key={order.id} className="card-glow">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-gray-400 text-sm">Customer</p>
                      <p className="font-semibold">{order.customerName}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Email</p>
                      <p className="text-sm">{order.userEmail}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Product</p>
                      <p className="font-semibold">{order.productName}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Status</p>
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                        order.status === "Approved"
                          ? "bg-green-500/20 text-green-400"
                          : order.status === "Processing"
                          ? "bg-yellow-500/20 text-yellow-400"
                          : "bg-red-500/20 text-red-400"
                      }`}>
                        {order.status}
                      </span>
                    </div>
                  </div>

                  <div className="border-t border-neon-blue/20 pt-4 flex gap-2 flex-wrap">
                    {order.status === "Processing" && (
                      <>
                        <button
                          onClick={() => handleApproveOrder(order.id)}
                          className="flex items-center gap-1 px-4 py-1 rounded-lg bg-green-600 text-white hover:bg-green-700 transition text-sm font-semibold"
                        >
                          <Check size={14} />
                          Approve
                        </button>
                        <button
                          onClick={() => handleRejectOrder(order.id)}
                          className="flex items-center gap-1 px-4 py-1 rounded-lg bg-red-600 text-white hover:bg-red-700 transition text-sm font-semibold"
                        >
                          <X size={14} />
                          Reject
                        </button>
                      </>
                    )}
                    <button
                      onClick={() => setShowOrderDetails(order)}
                      className="flex items-center gap-1 px-4 py-1 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition text-sm font-semibold"
                    >
                      <Eye size={14} />
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {orders.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-400">No orders yet</p>
              </div>
            )}
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div>
            <h2 className="text-2xl font-bold mb-6">User Management</h2>
            <div className="space-y-4">
              {users.map((user) => (
                <div key={user.id} className="card-glow">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{user.name}</p>
                      <p className="text-gray-400 text-sm">{user.email}</p>
                      <p className="text-gray-500 text-xs">
                        Joined: {new Date(user.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <button
                      onClick={() => handleDeleteUser(user.id)}
                      className="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 transition text-sm font-semibold"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {users.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-400">No users yet</p>
              </div>
            )}
          </div>
        )}

        {/* Devices Tab */}
        {activeTab === "devices" && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Admin Device Management</h2>
            <div className="mb-6">
              <div className="card-glow">
                <p className="text-gray-400 text-sm mb-2">Active Admin Devices</p>
                <p className="text-3xl font-bold text-green-400">
                  {devices.length} {devices.length === 1 ? "Device" : "Devices"}
                </p>
              </div>
            </div>

            {devices.length > 0 ? (
              <div className="space-y-4">
                {devices.map((device) => (
                  <div key={device.id} className="card-glow">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-gray-400 text-sm mb-1">Device Name</p>
                        <p className="font-semibold">{device.deviceName}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm mb-1">Browser</p>
                        <p className="font-semibold">{device.browserName}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm mb-1">Login Time</p>
                        <p className="text-sm">
                          {new Date(device.loginTime).toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm mb-1">IP Address</p>
                        <p className="font-mono text-sm">
                          {device.ipAddress === "Unknown"
                            ? "N/A"
                            : device.ipAddress}
                        </p>
                      </div>
                    </div>
                    <div className="border-t border-neon-blue/20 pt-4 flex justify-between items-center">
                      <span className="text-xs text-gray-500">
                        Session ID: {device.id.substring(0, 20)}...
                      </span>
                      <button
                        onClick={() => {
                          const updatedDevices = devices.filter(
                            (d) => d.id !== device.id
                          );
                          setDevices(updatedDevices);
                          localStorage.setItem(
                            "adminDevices",
                            JSON.stringify(updatedDevices)
                          );
                        }}
                        className="px-3 py-1 rounded-lg bg-red-600 text-white hover:bg-red-700 transition text-xs font-semibold"
                      >
                        Revoke Access
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="card-glow text-center py-8">
                <Smartphone size={48} className="mx-auto text-gray-600 mb-4" />
                <p className="text-gray-400">No active admin devices</p>
              </div>
            )}
          </div>
        )}

        {/* QR Code Tab */}
        {activeTab === "qr" && (
          <div>
            <h2 className="text-2xl font-bold mb-6">QR Code Management</h2>
            <div className="card-glow">
              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">
                  QR Code Image URL
                </label>
                <input
                  type="url"
                  value={qrCode}
                  onChange={(e) => handleQRCodeUpload(e.target.value)}
                  className="w-full px-4 py-2 bg-black/50 border border-neon-blue/30 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-neon-blue"
                  placeholder="Enter QR code image URL"
                />
              </div>
              <div className="text-center p-6 bg-white/5 rounded-lg">
                {qrCode ? (
                  <img
                    src={qrCode}
                    alt="Current QR Code"
                    className="w-full max-w-xs mx-auto"
                  />
                ) : (
                  <p className="text-gray-400">No QR code set</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Order Details Modal */}
        {showOrderDetails && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="card-glow max-w-md w-full">
              <h3 className="text-lg font-bold mb-4">Order Details</h3>
              <div className="space-y-3 mb-4">
                <div>
                  <p className="text-gray-400 text-sm">Customer Name</p>
                  <p className="font-semibold">{showOrderDetails.customerName}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Email</p>
                  <p className="text-sm">{showOrderDetails.userEmail}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Product</p>
                  <p className="font-semibold">{showOrderDetails.productName}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">UTR Number</p>
                  <p className="font-mono text-sm">{showOrderDetails.utrNumber}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Order Date</p>
                  <p className="text-sm">
                    {new Date(showOrderDetails.orderDate).toLocaleString()}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowOrderDetails(null)}
                className="w-full py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
